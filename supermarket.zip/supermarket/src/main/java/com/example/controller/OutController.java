package com.example.controller;

import com.example.entity.LayUITable;
import com.example.entity.Outrecord;
import com.example.service.OutBiz;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class OutController {
    @Autowired
    private OutBiz outBizimpl;
    @RequestMapping("/tooutrecord")
    public String tooutrecord(){
        return "outrecord";
    }
    @RequestMapping("/outTable")
    @ResponseBody
    public LayUITable outTable(int page, int limit){
        PageHelper.startPage(page, limit);

        List<Outrecord> list=outBizimpl.SelectAllOut();

        PageInfo<Outrecord> pageInfo=new PageInfo(list);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }
}
