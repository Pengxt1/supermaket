package com.example.controller;

import com.example.entity.Inrecord;
import com.example.entity.LayUITable;
import com.example.entity.Outrecord;
import com.example.entity.Product;
import com.example.service.InBiz;
import com.example.service.OutBiz;
import com.example.service.ProductBiz;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ProductController {
    @Autowired
    private ProductBiz productBizimpl;
    @Autowired
    private OutBiz outBizimpl;
    @Autowired
    private InBiz inBizimpl;


    @RequestMapping("/AddPro")
    public String AddPro(String PName, int PPrice, Model model){
        Product product=productBizimpl.SelectbyPname(PName);
        if(null!=product){
            model.addAttribute("message","商品已存在");
            return "menu1";
        }
        Product product1=new Product();
        product1.setPname(PName);
        product1.setPprice(PPrice);
        productBizimpl.insertSelective(product1);
        return "main";
    }
    @RequestMapping("/table_all")
    @ResponseBody
    public LayUITable Alltable(int page, int limit){
        PageHelper.startPage(page, limit);

        List<Product> productList=productBizimpl.SelectAllProduct();

        PageInfo<Product> pageInfo=new PageInfo(productList);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }

    @RequestMapping("/table1")
    @ResponseBody
    public LayUITable table1(int page, int limit,String pname){
        PageHelper.startPage(page, limit);

        List<Product> productList=productBizimpl.SelectProductByname(pname);

        PageInfo<Product> pageInfo=new PageInfo(productList);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }
    @RequestMapping("/table2")
    @ResponseBody
    public LayUITable table2(int page, int limit,int stock1,int stock2){
        PageHelper.startPage(page, limit);

        List<Product> productList=productBizimpl.SelectProductBystock(stock1,stock2);

        PageInfo<Product> pageInfo=new PageInfo(productList);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }
    @RequestMapping("/table3")
    @ResponseBody
    public LayUITable table3(int page, int limit,int sell1,int sell2){
        PageHelper.startPage(page, limit);

        List<Product> productList=productBizimpl.SelectProductBysell(sell1,sell2);

        PageInfo<Product> pageInfo=new PageInfo(productList);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }

    //删除商品信息
    @RequestMapping("/delProduct")
    @ResponseBody
    public Object delProduct(int no){
        int i=productBizimpl.deleteByPrimaryKey(no);
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message","删除成功");
        }else {
            map.put("code",-1);
            map.put("message","删除失败");
        }
        return map;
    }


    //进货
    @RequestMapping("/adds")
    @ResponseBody
    public Object adds(@Param("no")int no,@Param("add")int add,@Param("PName")String PName){
        int i=productBizimpl.addStock(no,add);
        Map map= new HashMap<>();
        if(i>0){
            Inrecord inrecord=new Inrecord();
            inrecord.setNo(no);
            inrecord.setInnum(add);
            inrecord.setPname(PName);
            Date t=new Date();
            inrecord.setIntime(t);
            inBizimpl.insert(inrecord);
            map.put("code",0);
            map.put("message","进货成功");
        }else {
            map.put("code",-1);
            map.put("message","进货失败");
        }
        return map;
    }


    //出售商品
    @RequestMapping("/sells")
    @ResponseBody
    public Object sells(@Param("no")int no,@Param("stock")int stock,@Param("sellNumber")int sellNumber,@Param("PName")String PName){
        Map map= new HashMap<>();
        if(stock<sellNumber){
            map.put("code",-2);
            map.put("message","供不应求，商品不足");
            return map;
        }
        int i=productBizimpl.sell(no,sellNumber);
        if(i>0){
            Outrecord outrecord=new Outrecord();
            outrecord.setNo(no);
            outrecord.setOutnum(sellNumber);
            outrecord.setPname(PName);
            Date t=new Date();
            outrecord.setOuttime(t);
            outBizimpl.insert(outrecord);
            map.put("code",0);
            map.put("message","出售成功");
        }else {
            map.put("code",-1);
            map.put("message","出售失败");
        }
        return map;
    }

    //修改商品信息
    @RequestMapping("/updates")
    @ResponseBody
    public Object updates(@Param("no")int no,@Param("pname")String pname,@Param("pprice")int pprice,@Param("stock")int stock,@Param("salesVolume")int salesVolume){
        Product product=new Product();
        product.setNo(no);
        product.setPname(pname);
        product.setPprice(pprice);
        product.setStock(stock);
        product.setSalesVolume(salesVolume);
        int i=productBizimpl.updateByPrimaryKey(product);
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message","修改成功");
        }else {
            map.put("code",-1);
            map.put("message","修改失败");
        }
        return map;
    }
}
