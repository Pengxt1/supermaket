package com.example.controller;

import com.example.entity.Perms;
import com.example.service.PermsBiz;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PermsController {
    @Autowired
    private PermsBiz permsBizimpl;

    //显示权限
    @RequestMapping("/select_perms")
    @ResponseBody
    public Object select_perms(int id){
        List<Perms> list=permsBizimpl.getPermsbyId(id);
        Map map= new HashMap<>();
        map.put("list",list);
        return map;
    }
    //修改权限
    @RequestMapping("/update_perms")
    @ResponseBody
    public Object update_perms(@Param("id1") int id1,@Param("qx1")String[]qx1){
        int i=1;
        if(qx1==null){
            i=permsBizimpl.deletePermsbyId(id1);
        }
        else{
            permsBizimpl.deletePermsbyId(id1);
            for(int j=0;j<qx1.length;j++){
                Perms perm=new Perms();
                perm.setId(id1);
                perm.setPerm(qx1[j]);
                i=permsBizimpl.insert(perm);
            }
        }
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message"," 设置成功");
        }else {
            map.put("code",-1);
            map.put("message","设置失败");
        }
        return map;
    }
}
