package com.example.controller;

import com.example.entity.LayUITable;
import com.example.entity.User;
import com.example.service.UserBiz;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class UserController {
    @Autowired
    private UserBiz userBizimpl;
    @RequestMapping("/User_all")
    @ResponseBody
    public LayUITable User_all(int page, int limit){
        PageHelper.startPage(page, limit);

        List<User> userList=userBizimpl.selectAllUser();

        PageInfo<User> pageInfo=new PageInfo(userList);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }
    //删除用户
    @RequestMapping("/delUser")
    @ResponseBody
    public Object delUser(int id){
        int i=userBizimpl.deleteByPrimaryKey(id);
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message"," 删除成功");
        }else {
            map.put("code",-1);
            map.put("message","删除失败");
        }
        return map;
    }
    //添加用户
    @RequestMapping("/adds_user")
    @ResponseBody
    public Object adds_user(@Param("account")String account, @Param("password")String password){
        User user=new User();
        user.setAccount(account);
        user.setPassword(password);
        int i=userBizimpl.insertSelective(user);
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message","添加成功");
        }else {
            map.put("code",-1);
            map.put("message","添加失败");
        }
        return map;
    }
    //修改用户
    @RequestMapping("/ups")
    @ResponseBody
    public Object ups(@Param("id")int id,@Param("account")String account,@Param("password")String password){
        User user=new User();
        user.setId(id);
        user.setAccount(account);
        user.setPassword(password);
        int i=userBizimpl.updateByPrimaryKey(user);
        Map map= new HashMap<>();
        if(i>0){
            map.put("code",0);
            map.put("message"," 修改成功");
        }else {
            map.put("code",-1);
            map.put("message","修改失败");
        }
        return map;
    }

}
