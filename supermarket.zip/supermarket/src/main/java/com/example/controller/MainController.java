package com.example.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
    @RequestMapping("/toLogin")
    public String toLogin(){
        return "login";
    }
    @RequestMapping("/Login")
    public String Login(String account,String password,Model model){
        //获取shiro的主体
        Subject subject = SecurityUtils.getSubject();
        //构建用户登录令牌
        UsernamePasswordToken token= new UsernamePasswordToken(account,password);
        try {
            subject.login(token);
        }catch (UnknownAccountException e){
            model.addAttribute("message","用户名错误");
            return "login";
        }catch (IncorrectCredentialsException e){
            model.addAttribute("message","密码错误");
            return "login";
        }
        return "main";
    }
    //注销
    @RequestMapping("/logout")
    public String logout(){
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        return "login";
    }
    @RequestMapping("/toMain")
    public String toMain(){
        return "main";
    }
    @RequestMapping("/toMenu0")
    public String toMenu0(){
        return "menu0";
    }
    @RequestMapping("/toMenu1")
    public String toMenu1(){
        return "menu1";
    }
    @RequestMapping("/toMenu2")
    public String toMenu2(){
        return "menu2";
    }
    @RequestMapping("/toMenu3")
    public String toMenu3() { return "menu3"; }
    @RequestMapping("/toMenu4")
    public String toMenu4(){
        return "menu4";
    }
    @RequestMapping("/toMenu5")
    public String toMenu5(){
        return "menu5";
    }
    @RequestMapping("/toMenu6")
    public String toMenu6(){
        return "menu6";
    }
    @RequestMapping("/toMenu7")
    public String toMenu7(){
        return "menu7";
    }

}
