package com.example.controller;

import com.example.entity.Inrecord;
import com.example.entity.LayUITable;
import com.example.service.InBiz;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class InController {
    @Autowired
    private InBiz inBizimpl;
    @RequestMapping("/toinrecord")
    public String toinrecord(){
        return "inrecord";
    }
    @RequestMapping("/inTable")
    @ResponseBody
    public LayUITable inTable(int page, int limit){
        PageHelper.startPage(page, limit);

        List<Inrecord> list=inBizimpl.SelectAllIn();
        PageInfo<Inrecord> pageInfo=new PageInfo(list);
        LayUITable layUITable=new LayUITable();
        layUITable.setCode(0);
        layUITable.setMsg("返回信息");
        layUITable.setCount(pageInfo.getTotal());
        layUITable.setData(pageInfo.getList());
        return layUITable;
    }
}
