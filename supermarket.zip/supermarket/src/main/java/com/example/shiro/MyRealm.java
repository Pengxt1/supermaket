package com.example.shiro;


import com.example.entity.Perms;
import com.example.entity.User;
import com.example.service.PermsBiz;
import com.example.service.UserBiz;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class MyRealm extends AuthorizingRealm {
    @Autowired
    private UserBiz userBizimpl;
    @Autowired
    private PermsBiz permsBizimpl;
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        System.out.println("授权开始");
        SimpleAuthorizationInfo simpleAuthorizationInfo=new SimpleAuthorizationInfo();
        User userInfo= (User)SecurityUtils.getSubject().getPrincipal();
        int id=userInfo.getId();
        List<Perms> list=permsBizimpl.getPermsbyId(id);
        for(int i=0;i<list.size();i++){
            simpleAuthorizationInfo.addStringPermission(list.get(i).getPerm());
        }
        return simpleAuthorizationInfo;
    }
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("认证开始");
        //开始校验用户名和密码
        //取出令牌信息
        UsernamePasswordToken usernamePasswordToken= (UsernamePasswordToken) token;
        //登录验证分两个步骤，步骤一查询用户是否存在
        String username=usernamePasswordToken.getUsername();
        User userInfo = userBizimpl.selectUserByUsername(username);
        if(null==userInfo){
            return null;
        }
        //步骤二，查询密码是否正确
        //数据库中的密码
        String password=userInfo.getPassword();
        //Object principal, Object credentials, String realmName
        SimpleAuthenticationInfo simpleAuthenticationInfo= new SimpleAuthenticationInfo(userInfo,password,"");
        return simpleAuthenticationInfo;
    }
}
