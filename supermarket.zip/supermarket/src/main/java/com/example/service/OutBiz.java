package com.example.service;

import com.example.entity.Outrecord;

import java.util.List;

public interface OutBiz {
    int insert(Outrecord record);
    List<Outrecord> SelectAllOut();
}
