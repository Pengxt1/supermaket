package com.example.service;

import com.example.entity.User;

import java.util.List;

public interface UserBiz {
    User selectUserByUsername(String account);
    List<User> selectAllUser();
    int insertSelective(User record);
    int updateByPrimaryKey(User record);
    int deleteByPrimaryKey(Integer id);
}
