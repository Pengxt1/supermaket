package com.example.service.impl;

import com.example.dao.PermsMapper;
import com.example.entity.Perms;
import com.example.service.PermsBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermsBizimpl implements PermsBiz {
    @Autowired
    private PermsMapper permsMapper;
    public List<Perms> getPermsbyId(int id){
        List<Perms> list=permsMapper.getPermsbyId(id);
        return list;
    }
    public int deletePermsbyId(int id){
        int i=permsMapper.deletePermsbyId(id);
        return i;
    }
    public int insert(Perms record){
        int i=permsMapper.insert(record);
        return i;
    }
}
