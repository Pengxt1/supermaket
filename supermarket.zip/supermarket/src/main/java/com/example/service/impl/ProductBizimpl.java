package com.example.service.impl;

import com.example.dao.ProductMapper;
import com.example.entity.Product;
import com.example.service.ProductBiz;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductBizimpl implements ProductBiz {
    @Autowired
    private ProductMapper productMapper;
    public Product SelectbyPname(String pname){
        Product product=productMapper.SelectbyPname(pname);
        return product;
    }
    public int insertSelective(Product record){
        int i=productMapper.insertSelective(record);
        return i;
    }
    public List<Product> SelectAllProduct(){
        List<Product> productList=productMapper.SelectAllProduct();
        return productList;
    }
    public List<Product> SelectProductByname(String pname){
        List<Product> productList=productMapper.SelectProductByname(pname);
        return productList;
    }
    public List<Product> SelectProductBystock(@Param("stock1")int stock1,@Param("stock2")int stock2){
        List<Product> productList=productMapper.SelectProductBystock(stock1,stock2);
        return productList;
    }
    public List<Product> SelectProductBysell(@Param("sell1")int sell1,@Param("sell2")int sell2){
        List<Product> productList=productMapper.SelectProductBysell(sell1,sell2);
        return productList;
    }
    public int deleteByPrimaryKey(Integer no){
        int i=productMapper.deleteByPrimaryKey(no);
        return i;
    }
    public int addStock(@Param("no")int no, @Param("add")int add){
        int i=productMapper.addStock(no,add);
        return i;
    }
    public int sell(@Param("no")int no, @Param("sellNumber")int sellNumber){
        int i=productMapper.sell(no,sellNumber);
        return i;
    }
    public int updateByPrimaryKey(Product record){
        int i=productMapper.updateByPrimaryKey(record);
        return i;
    }
}
