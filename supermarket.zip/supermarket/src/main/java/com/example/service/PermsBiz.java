package com.example.service;

import com.example.entity.Perms;

import java.util.List;

public interface PermsBiz {
    List<Perms> getPermsbyId(int id);
    int deletePermsbyId(int id);
    int insert(Perms record);
}
