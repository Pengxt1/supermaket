package com.example.service.impl;

import com.example.dao.UserMapper;
import com.example.entity.User;
import com.example.service.UserBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserBizimpl implements UserBiz {
    @Autowired
    private UserMapper userMapper;
    public User selectUserByUsername(String account){
        User user=userMapper.selectUserByUsername(account);
        return user;
    }
    public List<User> selectAllUser(){
        List<User> list=userMapper.selectAllUser();
        return list;
    }
    public int insertSelective(User record){
        int i=userMapper.insertSelective(record);
        return i;
    }
    public int updateByPrimaryKey(User record){
        int i=userMapper.updateByPrimaryKey(record);
        return i;
    }
    public int deleteByPrimaryKey(Integer id){
        int i=userMapper.deleteByPrimaryKey(id);
        return i;
    }

}
