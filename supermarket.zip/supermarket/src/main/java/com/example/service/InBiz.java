package com.example.service;

import com.example.entity.Inrecord;

import java.util.List;

public interface InBiz {
    int insert(Inrecord record);
    List<Inrecord> SelectAllIn();
}
