package com.example.service.impl;

import com.example.dao.OutrecordMapper;
import com.example.entity.Outrecord;
import com.example.service.OutBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OutBizimpl implements OutBiz {
    @Autowired
    private OutrecordMapper outrecordMapper;
    public int insert(Outrecord record){
        int i=outrecordMapper.insert(record);
        return i;
    }
    public List<Outrecord> SelectAllOut(){
        List<Outrecord> list=outrecordMapper.SelectAllOut();
        return list;
    }
}
