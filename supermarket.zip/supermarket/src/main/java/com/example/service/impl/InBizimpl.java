package com.example.service.impl;

import com.example.dao.InrecordMapper;
import com.example.entity.Inrecord;
import com.example.service.InBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InBizimpl implements InBiz {
    @Autowired
    private InrecordMapper inrecordMapper;
    public int insert(Inrecord record){
        int i=inrecordMapper.insert(record);
        return i;
    }
    public List<Inrecord> SelectAllIn(){

        List<Inrecord> list=inrecordMapper.SelectAllIn();
        return list;
    }
}
