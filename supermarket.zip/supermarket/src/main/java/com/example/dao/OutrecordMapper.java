package com.example.dao;

import com.example.entity.Outrecord;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface OutrecordMapper {
    int insert(Outrecord record);
    List<Outrecord> SelectAllOut();
}