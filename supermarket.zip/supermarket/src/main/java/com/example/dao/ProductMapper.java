package com.example.dao;

import com.example.entity.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ProductMapper {
    int deleteByPrimaryKey(Integer no);

    int insert(Product record);

    int insertSelective(Product record);

    Product selectByPrimaryKey(Integer no);

    int updateByPrimaryKeySelective(Product record);

    int updateByPrimaryKey(Product record);

    Product SelectbyPname(String pname);
    List<Product> SelectAllProduct();
    List<Product> SelectProductByname(String pname);
    List<Product> SelectProductBystock(@Param("stock1")int stock1,@Param("stock2")int stock2);
    List<Product> SelectProductBysell(@Param("sell1")int sell1,@Param("sell2")int sell2);
    int addStock(@Param("no")int no, @Param("add")int add);
    int sell(@Param("no")int no, @Param("sellNumber")int sellNumber);
}