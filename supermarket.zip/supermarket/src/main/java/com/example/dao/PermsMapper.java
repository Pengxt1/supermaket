package com.example.dao;

import com.example.entity.Perms;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface PermsMapper {
    int insert(Perms record);

    int insertSelective(Perms record);
    List<Perms> getPermsbyId(int id);
    int deletePermsbyId(int id);
}