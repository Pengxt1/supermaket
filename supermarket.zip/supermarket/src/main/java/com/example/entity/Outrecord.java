package com.example.entity;


import lombok.Data;

import java.util.Date;
@Data
public class Outrecord {
    private Integer no;

    private String pname;

    private Integer outnum;

    private Date outtime;


}