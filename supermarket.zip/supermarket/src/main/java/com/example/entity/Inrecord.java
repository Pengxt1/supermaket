package com.example.entity;

import lombok.Data;

import java.util.Date;
@Data
public class Inrecord {
    private Integer no;

    private String pname;

    private Integer innum;

    private Date intime;


}